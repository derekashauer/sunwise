const o="0.7.2";export{o as A};
